<?php
include_once 'Modelo/clsconexion.php';

class clsInventario extends clsconexion{

	
	
	public function ConsultaGlobal()
	{
		$sql = " CALL consulta_generar_inventario();";
       
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}	
}


?>
