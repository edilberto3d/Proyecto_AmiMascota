<?php
include_once 'Modelo/clsconexion.php';

class clsNosotros extends clsconexion{

	
	public function crearusuarios($usuario,$passw)
	{
		$sql = "CALL spCrearUsuarios('$usuario','$passw');";
       
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}	

}


?>