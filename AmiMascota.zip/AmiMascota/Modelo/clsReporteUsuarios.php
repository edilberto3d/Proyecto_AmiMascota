<?php
include_once 'Modelo/clsconexion.php';

class clsReporteUsuarios extends clsconexion{

	public function insertarfabricante($nombre,$ap,$am,$edad,$sexo,$telefono,$email,$usuario,$contraseña,$confirmar_contraseña) {
		
		$sql = "CALL sp_Inserta_Cliente('$nombre','$ap','$am','$edad','$sexo','$telefono','$email','$usuario','$contraseña','$confirmar_contraseña');";
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
		   
	}
	
	public function Actualizar($id_cliente,$nombre,$ap,$am,$edad,$sexo,$telefono,$email,$usuario,$contraseña,$confirmar_contraseña)
	{
		$sql = "CALL sp_Actualiza_Cliente('$id_cliente','$nombre','$ap','$am','$edad','$sexo','$telefono','$email','$usuario','$contraseña','$confirmar_contraseña');";
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}
	public function Eliminar($id_cliente)
	{
		
		$sql = "CALL sp_Elimina_Cliente('$id_cliente');"; 
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}
	
	public function ConsultaFabricante()
	{
		$sql =  "CALL sp_Cosulta_Cliente();";

		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}
}
?>