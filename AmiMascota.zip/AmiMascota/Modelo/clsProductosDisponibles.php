<?php
include_once 'Modelo/clsconexion.php';

class clsProductosDisponibles extends clsconexion{

	public function consultaFabricante() {
		
		$sql = "SELECT *FROM tblcategoria;"; //	CALL spConsultaFabricantes
		$resultado = $this->conectar->query($sql);
		return $resultado;
		   
	}
    public function insertarProductos($nombre,$descripcion,$stock,$precio,$hora,$fecha_registro,$imagen,$id_categoria) {
		
		$sql = "CALL Insertar_producto('$nombre','$descripcion','$stock','$precio','$hora','$fecha_registro','$imagen','$id_categoria');";
        $resultado = $this->conectar->query($sql);
		return $resultado;
		   
	}
	public function Actualizar($id_producto,$nombre,$descripcion,$stock,$precio,$hora,$fecha_registro,$id_categoria)
	{
		
		$sql = "CALL actualizar_producto('$id_producto','$nombre','$descripcion','$stock','$precio','$hora','$fecha_registro','$id_categoria');";
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}
	public function Eliminar($id_producto)
	{
		
		$sql = "CALL sp_elimina_producto('$id_producto');";
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}
	public function consultaProducto() {
		
		$sql = "SELECT *FROM tblproducto;";
		$resultado = $this->conectar->query($sql);
		return $resultado;
		   
	}
	
}

?>