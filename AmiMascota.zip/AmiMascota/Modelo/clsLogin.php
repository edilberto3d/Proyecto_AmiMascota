<?php
include_once 'Modelo/clsconexion.php';

class clsLogin extends clsconexion{

	
	public function buscausuario($usuario,$passw)
	{
		$sql = "CALL sp_Busca_Usuario('$usuario','$passw');";
       
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}	

	public function Crearusuarios($usuario,$passw,$tipo)
	{

		$sql="CALL sp_inserta_usuarios('$usuario','$passw','$tipo');";
		$resultado = $this->conectar->query($sql);
		return $resultado;

	}
}
?>