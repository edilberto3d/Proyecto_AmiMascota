<?php
include_once 'Modelo/clsconexion.php';

class clsProductos extends clsconexion{

	public function consultaFabricante() {
		
		$sql = "CALL sp_consulta_categoria();"; //	CALL spConsultaFabricantes
		$resultado = $this->conectar->query($sql);
		return $resultado;
		   
	}
    public function insertarProductos($nombre,$descripcion,$stock,$precio,$hora,$fecha_registro,$imagen,$id_categoria) {
		
		$sql = "CALL Insertar_producto('$nombre','$descripcion','$stock','$precio','$hora','$fecha_registro','$imagen','$id_categoria');";
        $resultado = $this->conectar->query($sql);
		return $resultado;
		   
	}
	public function Actualizar($id_producto,$nombre,$descripcion,$stock,$precio,$hora,$fecha_registro,$id_categoria)
	{
		
		$sql = "CALL actualizar_producto('$id_producto','$nombre','$descripcion','$stock','$precio','$hora','$fecha_registro','$id_categoria');";
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}
	public function Eliminar($id_producto)
	{
		
		$sql = "CALL sp_elimina_producto('$id_producto');";
		$resultado = $this->conectar->query($sql);
		
		return $resultado;
	}
	public function consultaProducto() {
		
		$sql = "CALL sp_consulta_productos();";
		$resultado = $this->conectar->query($sql);
		return $resultado;
		   
	}
	
}

?>
