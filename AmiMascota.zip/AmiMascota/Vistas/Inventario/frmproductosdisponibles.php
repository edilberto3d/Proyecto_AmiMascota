<link rel="stylesheet" href="Estilos/StyleReportes.css">
<br><br>

<div class="product-container">
  <?php
    $productos = new clsProductosDisponibles();
    $resultados = $productos->ConsultaProducto();
    while ($prod = $resultados->fetch_object()) {
      $imagenData = $prod->img;
      $imagenSrc = 'data:image/*;base64,' . base64_encode($imagenData);
  ?>
  <div class="product-card">
    <img src="<?php echo $imagenSrc; ?>" alt="imagen" class="product-image">
    <h3 class="product-name"><?php echo $prod->nombre; ?></h3>
    <p class="product-description"><?php echo $prod->descripcion; ?></p>
    <p class="product-stock">Stock: <?php echo $prod->stock; ?></p>
    <p class="product-price">Precio: <?php echo $prod->precio; ?></p>
   
      <input type="hidden" name="txtnombre" value="<?php echo $prod->nombre; ?>">
      <input type="hidden" name="txtdescripcion" value="<?php echo $prod->descripcion; ?>">
      <input type="hidden" name="txtstock" value="<?php echo $prod->stock; ?>">
      <input type="hidden" name="txtprecio" value="<?php echo $prod->precio; ?>">
      <input type="hidden" name="txtimagen" value="<?php echo $imagenSrc; ?>">
      <button type="submit" class="btn-comprar">Comprar</button>
    </form>
  </div>
  <?php
    }
  ?>
</div>