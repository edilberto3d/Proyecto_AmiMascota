<link rel="stylesheet" href="Estilos/termycond.css">
<br><br><br><br>

<table class="inventory-table">
  <thead>
    <tr>
      <th>Id Inventario</th>
      <th>Id Producto</th>
      <th>Cantidad</th>
      <th>Hora</th>
      <th>Fecha</th>
    </tr>
  </thead>
  <tbody>
    <?php
      while ($fila = $Consulta->fetch_object()) {
        echo '<form class="form" action="#" method="POST">';
        echo '<tr>';
        echo '<td>' . $fila->id_inventario . '</td>';
        echo '<td>' . $fila->id_producto . '</td>';
        echo '<td> <input type="text" name="txtStock" value="' . $fila->stock . '" readonly ></td>';
        echo '<td> <input type="text" name="txtHora" value="' . $fila->hora . '" readonly ></td>';
        echo '<td> <input type="text" name="txtFecha" value="' . $fila->fecha . '" readonly ></td>';
        echo '</tr>';
        echo '</form>';
      }
    ?>
  </tbody>
</table>


<form action="/AmiMascota/index?clase=controladorinventario&metodo=reporteHistorial" method="POST">
  <center>
    <button type="submit" name="btnGenerar" value="btnGenerar" class="submit-button">Generar</button>
  </center>
</form>