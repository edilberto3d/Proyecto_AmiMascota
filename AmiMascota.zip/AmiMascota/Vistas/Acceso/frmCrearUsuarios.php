<br><br><br>
<form class="form" action="/AmiMascota/index?clase=controladorusuarios&metodo=CrearUsuario" method="POST">
<img src="img/logiin.png" alt="logiin" width="70px" height="70px">
    <h2>Crear Usuarios</h2>
    <div class="form-group">
      <label for="usuario">Usuario:</label>
      <input type="text" id="usuario" name="txtusuario" required>
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" id="password" name="txtpassword" required>
    </div>
    <div class="form-group">
        <select name="selectTipo" class="form-control">
        
                <option value="Administrador">Administrador</option>
                <option value="Normal">Normal</option>
       
        </select>
    </div>
    
    <div class="form-group">
      <button type="submit">Registrar</button>
    </div>
  </form>
