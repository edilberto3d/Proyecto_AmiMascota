
<form action="/AmiMascota/index?clase=controladornosotros&metodo=Nosotros" method="POST">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nosotros</title>
    <link rel="stylesheet" href="Estilos/EstiloNosotros.css">

    <body>

    <header class="animales">
        <img src="img/imagenes/animales.jpg"  alt="">
    </header>
    
    <div class="texto">
        <br>
        <h1> ¿Quienes Somos?</h1>
        <br>
        <p><samp>
          Somos una empresa 100% Mexicana. Tenemos Productos hechos en Mexico y<br>
          Productos importados. Todos nuestros diseños son desarrollados buscando lo<br>
          mejor para tus mascotas.<br><br>
          Buscamos seguridad, comodidad, diversion, calidad y precio.<br>
          Estamos siempre innovando para ofrecer productos de<br>
          Vanguardia y novedosos.
        </samp></p><br><br>
        
            <footer>
            <div class="container_footer">
                <div class="box_footer">
                    <div class="logo2">
                        <img src="./imagenes/nuevologo3.jpg.png" alt="">
                    </div><br><br><br><br><br><br>
                    <div class="terms">
                    
                        <p>          Una empresa comprometida a ofrecer a las familias con mascotas productos, accesorios y servicios enfocados a la salud, limpieza, cuidado, alimentación para sus mascotas rigiéndose bajo las normas de higiene y calidad, garantizando la satisfacción de nuestros clientes.</p>
                    </div>
                </div>
                <div class="box_footer">
                    <h2>Ubicacion:</h2>
                    <a href="https://goo.gl/maps/TAQfvwkDM6nEB5oF6"><i class="fa-solid fa-location-dot"></i> Velazquez Ibarra 51,<br>
                        centro, 43000 Huejutla,<br> 
                        Hgo., Huejutla de Reyes, Mexico
                    </a>
                </div>
         
                <div class="box_footer">
                    <h2>Redes sociales</h2>
                    <a href="https://web.facebook.com/profile.php?id=100082955072216"><i class="fa-brands fa-facebook-square"></i> Facebook</a>
                    <a href="#" title="Falta enlazar"><i class="fa-brands fa-twitter-square"></i> Twitter</Td></a>
                    <a href="#" title="Falta enlazar"><i class="fa-brands fa-whatsapp-square"></i> Whatsapp</a>
                    <a href="https://www.instagram.com/pet_shop_equipo4/"><i class="fa-brands fa-instagram-square"></i> Instagram</a>
                </div>
             </div>
    
</body>
</html>


