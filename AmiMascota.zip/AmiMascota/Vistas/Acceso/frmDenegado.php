<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="Estilos/Styles.css">
</head>
<body>
<br></br>
<form class="form" action="/AmiMascota/index?clase=controladorlogin&metodo=ingresar" method="POST" >
<img id="denegado" src="img/denegado.png" alt="denegado" width="50px" height="50px">
  
    <h2>ACCESO DENEGADO</h2>
      <p> NO PUEDES ACCEDER, CONSULTA CON EL ADMINISTRADOR</p>
          
         <div class="form-group">
      <button type="submit">REGRESAR</button>
    </div>
  </form>
</body>
</html>