<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRO</title>
    <link rel="stylesheet"   href="Estilos/cliente.css"> 
</head>
<body>
   
<br><br><br>
<form  action="/AmiMascota/index?clase=controladorfabricante&metodo=insertarproductos" method="POST">
  
  <div class="form-title">
  <h2>Registro de Cliente</h2></div>
  <form id="registration-form">
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="txtnombre" required>

    <label for="apellido_paterno">Apellido Paterno:</label>
    <input type="text" id="apellido_paterno" name="txtapa" required>

    <label for="apellido_materno">Apellido Materno:</label>
    <input type="text" id="apellido_materno" name="txtam" required>

    <label for="edad">Edad:</label>
    <input type="number" id="edad" name="txteda" min="5" required>

    <label for="sexo">Sexo:</label>
    <select id="sexo" name="txtsexo" required>
      <option value="masculino">Masculino</option>
      <option value="femenino">Femenino</option>
      <option value="otro">Otro</option>
    </select>

    <label for="telefono">Teléfono:</label>
    <input type="tel" id="telefono" name="txttelefono" pattern="[0-9]{10}" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="txtemail" required>

    <label for="usuario">Usuario:</label>
    <input type="text" id="usuario" name="txtusuario" pattern="^[a-zA-Z0-9]{4,16}$" required>

    <label for="contrasena">Contraseña:</label>
    <input type="password" id="contrasena" name="txtcontraseña" pattern="^(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d]{8,}$" required>

    <label for="confirmar_contrasena">Confirmar Contraseña:</label>
    <input type="password" id="confirmar_contrasena" name="txtconfirmar" required>
    <span class="error-message" id="password-error"></span>
    <br><br>
    <input type="submit" value="Registrarse"> 
  </form>


<style>

form {
    max-width: 400px;
    margin: 0 auto;
  }
  
  /* Estilo para los campos de entrada */
  input[type="text"],
  input[type="email"],
  input[type="number"],
  input[type="tel"],
  input[type="password"],
  select,
  textarea {
    width: 100%;
    padding: 6px;
    border: 2px solid #007bff;
    border-radius: 5px;
    margin-bottom: 15px;
    font-size: 16px;
  }
  
  /* Estilo para el botón de envío */
  input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  
  input[type="submit"]:hover {
    background-color: #0056b3;
  }
  
  /* Estilo para los mensajes de error */
  .error-message {
    color: #ff3333;
    font-size: 14px;
  }
  
  
  
  
  /* Estilo para el título del formulario */
  .form-title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #007bff;
  }
  
  /* Estilo para el fondo del formulario */
  form {
    background-color: #edafaf;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }
  
  /* Estilo para la animación de los campos al enfocar */
  input[type="text"]:focus,
  input[type="email"]:focus,
  input[type="password"]:focus,
  nput[type="number"]:focus,
  nput[type="tel"]:focus,
  select,
  textarea:focus {
    border-color: #72ce27;
    box-shadow: 0 0 5px #a9d347;
  }
  
  /* Estilo para la animación del botón al pasar el mouse */
  input[type="submit"]:hover {
    background-color: #0056b3;
    transform: scale(1.1);
  }
  
  /* Estilo para la tipografía creativa */
  body {
    font-family: "Comic Sans MS", cursive, sans-serif;
  }
</style>







</div>
</body>
</html> 