<br></br><br>
<div class="table-container">
  <table class="centered-table">
    <thead>
      <tr>
        <th>Id cliente</th>
        <th>Nombre</th>
        <th>AP</th>
        <th>AM</th>
        <th>Edad</th>
        <th>Sexo</th>
        <th>Telefono</th>
        <th>Email</th>
        <th>Usuario</th>
        <th>Contraseña</th>
        <th>Confirmacion</th>
        <th>Accion</th>

      </tr>
    </thead>
    <tbody>
    
      <?php
      $fabricante = new clsReporteUsuarios
      ();
      $resultados = $fabricante->ConsultaFabricante();
            while ($fab=$resultados->fetch_object()) {
              echo '<form class="form" action="/AmiMascota/index?clase=controladorreporteUser&metodo=ActualizarXEliminar" method="POST">';
                echo '<tr>';
                echo '<td> <input type="text" name="txtid_cliente" value="'.$fab->id_cliente.'" </td>';
                echo '<td> <input type="text" name="txtnombre" value="'.$fab->nombre.'" ></td>';
                echo '<td> <input type="text" name="txtapa" value="'.$fab->ap.'" ></td>';
                echo '<td> <input type="text" name="txtam" value="'.$fab->am.'" ></td>';
                echo '<td> <input type="text" name="txteda" value="'.$fab->edad.'" ></td>';
                echo '<td> <input type="text" name="txtsexo" value="'.$fab->sexo.'" ></td>';
                echo '<td> <input type="text" name="txttelefono" value="'.$fab->telefono.'" ></td>';
                echo '<td> <input type="text" name="txtemail" value="'.$fab->email.'" ></td>';
                echo '<td> <input type="text" name="txtusuario" value="'.$fab->usuario.'" ></td>';
                echo '<td> <input type="text" name="txtcontraseña" value="'.$fab->contraseña.'" ></td>';
                echo '<td> <input type="text" name="txtconfirmar" value="'.$fab->confirmar_contraseña.'" ></td>';
                echo '<td width=250>';
            
                echo '&nbsp;';
                echo '<button type="submit" name="btnEliminar" value="btnEliminar" class="submit-button">Eliminar</button>';
                echo '</td>';
                echo '</tr>';
                echo '</form>';
            }
      ?>
    
    </tbody>
  </table>
</div>
