<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="Estilos/Styles.css">
  <link rel="stylesheet" href="Estilos/Estilosv1.css">
  <link rel="stylesheet" href="Estilos/nivo-slider.css">
</head>
<body>
    <header>
		<div id="main-menu">

			<nav id="menu-area">
				<ul>
                <div class="logo">
                    <img src="img/STK-20230718-WA0017.webp" alt="Logo">
                </div>
				<li><a href="/AmiMascota/index?clase=controladorprincipal&metodo=inicio">Inicio</a></li>
					<li><a href="/AmiMascota/index?clase=controladorproductosDisponibles&metodo=insertarproductos">Productos disponibles</a></li>

					<li><a href="/AmiMascota/index?clase=controladornosotros&metodo=Nosotros">Nosotros</a></li>
					<li><a href="/AmiMascota/index?clase=controladorlogin&metodo=CerrarSesion">Cerrar sesión</a></li>

				</ul>
			</nav>
		</div>

	</header>
     <!-- Este es el cuerpo -->
	 <?php include_once($vista); ?>

<!-- Este es el pie de la pagina -->
<br></br>
<footer>
        <p> &copy; Todos los derechos reservados © 2023 <b>AmiMascotaCompany</b> <?php date('d-m-Y H:i') ?> </p>
</footer>

<style>
	.logo{

height: 1000px;
width: 105px;
position: relative;
/* position: absolute; */
right: 10;
top: 10;
text-align: right;
}
</style>

</body>
</html>
