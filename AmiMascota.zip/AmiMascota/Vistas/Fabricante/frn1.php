

     <!-- <form class="form" action="/AmiMascota/index?clase=controladorreportes&metodo=productos2" method="POST">
    <h3>Reporte de productos por categoria</h3><br><br>
    <div class="form-group">
      <label for="nombre">Ingresa la categoria del producto:</label>
      <input type="text" id="nombre" name="txtnombre" required>
    </div>

    <div class="form-group">
      <button type="submit">Buscar</button>
    </div>
  </form> -->
