<form  action="/AmiMascota/index?clase=controladorreportes&metodo=reporteproductos" method="POST">
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRODUCTOS</title>
    <link rel="shortcut icon" href="./imagenes/LogoShop.jpeg" >
</head>
<body>    
<link rel="stylesheet" href="Estilos/proyecto.css">
        <h1>ACCESORIOS</h1>
        <br><br>
        <section class="row">
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/img/programador.jpg" alt="producto 1" class="imagen-catalogo">
                </div>
               <p>Kit de moño de corbata para perro</p>
               <strong>$120.00</strong>
               <br>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
    
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/accesorio2.jpg" alt="producto 2" class="imagen-catalogo">
                </div>
               <p>Kit de moños para perro hembra</p>
               <strong>$150.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
    
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/accesorio3.jpg" alt="producto 3" class="imagen-catalogo">
                </div>
               <p>Kit de pañoleta para perro</p>
               <strong>$250.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
            <br>
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/accesorio4.jpg" alt="producto 3" class="imagen-catalogo">
                </div>
               <p>Cepillo Removedor de pelo Mascotas</p>
               <strong>$284.30</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/accesorio5.jpg" alt="producto 3" class="imagen-catalogo">
                </div>
               <p>Cama para Perro</p>
               <strong>$219.99</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/accesorio6.webp" alt="producto 3" class="imagen-catalogo">
                </div>
               <p>Juguete mordedera para perro</p>
               <strong>$180.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
            <br>
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/accesorio7.jpg" alt="producto 3" class="imagen-catalogo">
                </div>
               <p>Collar Tactico para perro</p>
               <strong>$283.60</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
                </a>
            </div>

               <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/accesorio8.jpg" alt="producto 3" class="imagen-catalogo">
                </div>
               <p>Casa Rascador para gato</p>
               <strong>$520.50</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
                </a>
               </div>

               <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/accesorio9.jpg" alt="producto 3" class="imagen-catalogo">
                </div>
               <p>Kit de saco para perro</p>
               <strong>$360.20</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
                </a>
               </div>
               <br>
               <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/accesorio10.jpg" alt="producto 3" class="imagen-catalogo">
                </div>
               <p>Sueter lana para gato</p>
               <strong>$200.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
                </a>
               </div>


        </section>
          <br><br>
        <h2>ALIMENTOS</h2>
        <br>
        <section class="row">
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentop1.jpg" alt="producto 1" class="imagen-catalogo">
                </div>
               <p>Alimento Purina BENEFUL para perro Adulto 10,1kg</p>
               <strong>$849.99</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
    
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentog2.jpg" alt="producto 2" class="imagen-catalogo">
                </div>
               <p>Alimento Minino pollo y pescado 1.3kg</p>
               <strong>$181.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
    
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentoc3.jpg" alt="producto 3" class="imagen-catalogo">
                </div> 
               <p>KAYTEE Alimento para conejo Forti-Diet 227kg</p>
               <strong>$290.30</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
            <br>
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentoa4.jpg" alt="producto 3" class="imagen-catalogo">
                </div> 
               <p>Alimento Extra Aves Silvestres Marvell 500g</p>
               <strong>$115.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>

            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentoH5.jpeg.jpg" alt="producto 3" class="imagen-catalogo">
                </div> 
               <p>Cunipic Premium Alimento Seco 
                para Hamster Todas las Edades, 800g
               </p>
               <strong>$119.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>

            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentoI6.jpg" alt="producto 3" class="imagen-catalogo">
                </div> 
               <p>Mazuri alimento para iguanas 450g</p>
               <strong>$145.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
            <br>
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentoT7.png" alt="producto 3" class="imagen-catalogo">
                </div> 
               <p>Lomas Reptiles Sticks Baby 
                Alimento Para Reptiles Acuaticos 70g
               </p>
               <strong>$108.34</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>

            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentop8.webp.png" alt="producto 3" class="imagen-catalogo">
                </div> 
               <p>Alimento para Perro Top Choice Adulto 25kg</p>
               <strong>$749.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>

            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentog9.jpeg.jpg" alt="producto 3" class="imagen-catalogo">
                </div> 
               <p>Alimento Pro Plan OptiTract Urinary 
                para gato adulto sabor pollo y arroz 3kg
               </p>
               <strong>$860.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>
            <br>
            <div class="card estilo-a">
                <a href="#">
                <div class="img-container">
                    <img src="/imagenes/alimentoA10.jpg" alt="producto 3" class="imagen-catalogo">
                </div> 
               <p>Wild Harvest ParaKeet Advanced Nutrition Diet 1.8kg
               </p>
               <strong>$559.00</strong>
               <input type="submit" value="Comprar" id="submit" class="boton"><br>
               <input type="submit" value="Añadir al Carrito" id="submit" class="boton">
            </a>
            </div>

        </section>
</body>
</html>