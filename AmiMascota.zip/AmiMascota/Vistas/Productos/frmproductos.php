<br><br> <br>

<form class="form" action="/AmiMascota/index?clase=controladorproductos&metodo=insertarproductos" method="POST" enctype="multipart/form-data">
    <link rel="stylesheet" href="/stylproductos.css">

    <div>
      <h2 class="div1" for="">Registro de Productos</h2>
    </div><br>

    <div class="form-group">
      <label for="nombre">Nombre del producto:</label>
      <input type="text" id="nombre" name="nombre" required>
    </div>

    <div class="form-group">
      <label for="descripcion">Descripción:</label>
      <textarea id="descripcion" name="descripcion" required></textarea>
    </div>

    <div class="form-group">
      <label for="precio">stock:</label>
      <input type="number" id="stock" name="stock">
    </div>

    <div class="form-group">
      <label for="precio">Precio:</label>
      <input type="number" id="precio" name="precio" step="0.01" required>
    </div>

    <div class="form-group">
      <label for="hora">Hora:</label>
      <input type="time" id="hora" name="hora" required>
    </div>

    <div class="form-group">
      <label for="fecha">Fecha de registro:</label>
      <input type="date" id="fecha" name="fecha_registro" required>
    </div>

    <div class="form-group">
      <label for="imagen">Imagen:</label>
      <input type="file" id="imagen" name="txtimagen" accept="image/*">
    </div>

    <div class="form-group">
      <label for="categoria">Categoría:</label>
      <select id="categoria" name="categoria" required>
      <option value="">seleccione la categoria</option>
      <?php while($filas=$Consulta->fetch_object()){ ?>
                <option value="<?php echo $filas->id_categoria; ?>"> <?php echo $filas->categoria; ?></option>
            <?php } ?>
      </select>
    </div>

    <button type="submit">Enviar</button>
  </form>    
</form>


<br></br>
<div class="table-container">
  <table class="centered-table">
    <thead>
      <tr>
        <th>Id Producto</th>
        <th>Nombre</th>
        <th>Descripcion</th>
        <th>Stock</th>
        <th>Precio</th>
        <th>Hora</th>
        <th>Fecha</th>
        <th>Imagen</th>
        <th>Ctaegoria</th>
        <th>Accion</th>

      </tr>
    </thead>
    <tbody>
    
      <?php
            while ($prod= $Consultaproductos->fetch_object()) {
              $imagenData=$prod->img;
              $imagenSrc='data:image/*;base64,' . base64_encode($imagenData);
              
              echo '<form class="form" action="/AmiMascota/index?clase=controladorproductos&metodo=ActualizarXEliminar" method="POST">';
                echo '<tr>';
                echo '<td> <input type="text" name="txtcodigo_prod" value="'.$prod->id_producto.'" readonly> </td>';
                echo '<td> <input type="text" name="txtnombre" value="'.$prod->nombre.'" ></td>';
                echo '<td> <input type="text" name="txtdescripcion" value="'.$prod->descripcion.'" ></td>';
                echo '<td> <input type="text" name="txtstock" value="'.$prod->stock.'" ></td>';
                echo '<td> <input type="text" name="txtprecio" value="'.$prod->precio.'" ></td>';
                echo '<td> <input type="text" name="txthora" value="'.$prod->hora.'" ></td>';
                echo '<td> <input type="text" name="txtfecha" value="'.$prod->fecha_registro.'" ></td>';
                echo '<td> <img src=" '.$imagenSrc.' " name="txtimagen" alt="imagen" style="width: 150px; height:100px;"> </td>';
                echo '<td> <input type="text" name="txtcategoria" value="'.$prod->id_categoria.'" readonly></td>';
                echo '<td width=250>';
                echo '<button type="submit" name="btnActualizar" value="btnActualizar" class="submit-button" >Actualizar</button>';
                echo '&nbsp;';
                echo '<button type="submit" name="btnEliminar" value="btnEliminar" class="submit-button">Eliminar</button>';
                echo '</td>';
                echo '</tr>';
                
                echo '</form>';
            }
      
      ?>
   
    </tbody>
  </table>
</div>
