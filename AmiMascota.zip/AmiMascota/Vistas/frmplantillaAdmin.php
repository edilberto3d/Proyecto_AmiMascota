<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="Estilos/Styles.css">
  <link rel="stylesheet" href="Estilos/Estilosv1.css">
  <link rel="stylesheet" href="Estilos/nivo-slider.css">
</head>
<body>
    <header>
		<div id="main-menu">
			
			<nav id="menu-area">
				<ul>
				
				<li><a href="/AmiMascota/index?clase=controladorinventario&metodo=reporteHistorial">Inventario</a></li>
				<li><a href="/AmiMascota/index?clase=controladorproductos&metodo=insertarproductos">Registro de Productos</a></li>
			    <li><a href="/AmiMascota/index?clase=controladorusuarios&metodo=CrearUsuario">Crear Usuarios</a></li>
			   
				<li><a href="/AmiMascota/index?clase=controladorreporteUser&metodo=insertarproductos">Reporte Clientes</a></li>
				<li><a href="/AmiMascota/index?clase=controladorlogin&metodo=CerrarSesion">Cerrar sesión</a></li>
				</ul>
			</nav>
		</div>
	</header>  
     <!-- Este es el cuerpo -->
	 <?php include_once($vista); ?> 

<!-- Este es el pie de la pagina -->
<br></br>
<footer>
        <p> &copy; Todos los derechos reservados © 2023 <b>AmiMascotaCompany</b> <?php date('d-m-Y H:i') ?> </p>
</footer>
</body>
</html>
