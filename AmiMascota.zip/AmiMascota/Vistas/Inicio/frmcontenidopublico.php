<div id="htmlcaption1" class="nivo-html-caption">     
            <h1>Sean Bienvenidos</h1>
        </div>
        <div id="htmlcaption2" class="nivo-html-caption">     
            <h1>Acerca de Nosotros</h1>
        </div>
        <div id="htmlcaption3" class="nivo-html-caption">     
            <h1>Mira nuestra Promociones</h1>
        </div>
        <div id="htmlcaption4" class="nivo-html-caption">     
            <h1>Tenemos una gran variedad de accesorios</h1>
        </div>
        <div id="htmlcaption5" class="nivo-html-caption">     
            <h1>Espero encuentres lo que buscas</h1>
        </div>
        <div id="htmlcaption6" class="nivo-html-caption">     
            <h1>Gracias por visitar</h1>
        </div> 
    </div>
    <br><br>
    <br><br>
    <h3>Algunos Productos que te pueden interesar...</h3>
    <br>
    <section class="row">
        <div class="card estilo-a">
            <a href="#">
            <div class="img-container">
                <img src="img/Productos/51I3bNjM5SL._AC_SY679_.jpg" alt="producto 1" class="imagen-catalogo">
            </div>
           <p>Botellas de Agua</p>
           <strong>$89</strong>
        </a>
        </div>

        <div class="card estilo-a">
            <a href="#">
            <div class="img-container">
                <img src="img/Productos/51T9aJzSi3L._AC_SX679_.jpg" alt="producto 2" class="imagen-catalogo">
            </div>
           <p>Arnes</p>
           <strong>$199</strong>
        </a>
        </div>

    </section>
    <br><br>
    <h1 class="tituloprod">Categorias de accesorios</h1><br>
        <section class="productos">
            <a href="#image1">
                <img src="img/Productos/61pNjY0dAGL._AC_SX679_.jpg" alt=""><br><br><br>Accesorio para Perros</a>
            <a href="#image2">
                <img src="img/Productos/222.jpg" alt=""><br><br><br>Accesorio para Gatos</a>
            <a href="#image3">
                <img src="img/Productos/3333.jpg" alt=""><br><br><br>Accesorio para Aves</a>
            <a href="#image5">
                <img src="img/Productos/4444.jpg" alt=""><br><br><br>Accesorio para Roedores</a>
            <a href="#image6">
                <img src="img/Productos/5555.jpg" alt=""><br><br><br>Accesorio para Peces</a>
        </section>
        <article class="light-box" id="image1">
          <a href="#image6" class="next"></a>
          <img src="img/Productos/61pNjY0dAGL._AC_SX679_.jpg" alt="">
          <a href="#image2" class="next">></a>
          <a href="#" class="close">X</a>
        </article>

        <article class="light-box" id="image2">
            <a href="#image1" class="next"></a>
            <img src="img/Productos/222.jpg" alt="">
            <a href="#image3" class="next">></a>
            <a href="#" class="close">X</a>
          </article>

          <article class="light-box" id="image3">
            <a href="#image2" class="next"></a>
            <img src="img/Productos/3333.jpg" alt="">
            <a href="#image4" class="next">></i></a>
            <a href="#" class="close">X</a>
          </article>

          <article class="light-box" id="image4">
            <a href="#image3" class="next"></a>
            <img src="img/Productos/4444.jpg" alt="">
            <a href="#image5" class="next">></a>
            <a href="#" class="close">X</a>
          </article>

          <article class="light-box" id="image5">
            <a href="#image4" class="next"></a>
            <img src="img/Productos/5555.jpg" alt="">
            <a href="#image6" class="next">></a>
            <a href="#" class="close">X</a>
          </article>

          <article class="light-box" id="image6">
            <a href="#image5" class="next"></a>
            <img src="img/imagenes/accpeces.jpg" alt="">
            <a href="#image1" class="next">></a>
            <a href="#" class="close">X</a>
          </article>
          <footer>
            <div class="container_footer">
                <div class="box_footer">
                    <div class="logo2">
                        <img src="./imagenes/nuevologo3.jpg.png" alt="">
                    </div>
                    <div class="terms">
                    <h2>AmiMascota</h2>
                        <p>          Una empresa comprometida a ofrecer a las familias con mascotas productos, accesorios y servicios enfocados a la salud, limpieza, cuidado, alimentación para sus mascotas rigiéndose bajo las normas de higiene y calidad, garantizando la satisfacción de nuestros clientes.</p>
                    </div>
                </div>
                <div class="box_footer">
                    <h2>Ubicacion:</h2>
                    <a href="https://goo.gl/maps/TAQfvwkDM6nEB5oF6"><i class="fa-solid fa-location-dot"></i> Velazquez Ibarra 51,<br>
                        centro, 43000 Huejutla,<br> 
                        Hgo., Huejutla de Reyes, Mexico
                    </a>
                </div>
         
                <div class="box_footer">
                    <h2>Redes sociales</h2>
                    <a href="https://web.facebook.com/profile.php?id=100082955072216"><i class="fa-brands fa-facebook-square"></i> Facebook</a>
                    <a href="#" title="Falta enlazar"><i class="fa-brands fa-twitter-square"></i> Twitter</Td></a>
                    <a href="#" title="Falta enlazar"><i class="fa-brands fa-whatsapp-square"></i> Whatsapp</a>
                    <a href="https://www.instagram.com/pet_shop_equipo4/"><i class="fa-brands fa-instagram-square"></i> Instagram</a>
                </div>
            </div>