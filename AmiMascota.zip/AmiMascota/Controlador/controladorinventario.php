
<?php

include_once 'Modelo/clsInventario.php';
include_once 'LibreriaFPDF/fpdf.php';

class controladorinventario
{
	private $vista;
	
	
    public function reporteHistorial()
    {
        $historial=new clsInventario();
        if(!empty($_POST))
        {
            
           
            // Crear el objeto FPDF
            $pdf = new FPDF();
        
            // Agregar una página
            $pdf->AddPage();
            $pdf->Cell(190,30,$pdf->Image('img/imagenes/animales.jpg',130,12,60,30),0,1,'R');
        
            // Establecer la fuente y el tamaño del título
            $pdf->SetFont('Arial', 'B', 14);
            $pdf->SetLeftMargin(40);
            $pdf->Cell(0, 20,utf8_decode('Reporte Inventario'), 0, 1, 'C');

            // Consulta a la base de datos
            
            $Consulta=$historial->ConsultaGlobal();     
            //Centrar la tabla
            $pdf->SetLeftMargin(50);
            if ($Consulta->num_rows > 0) {
        
                // Establecer la fuente y el tamaño del encabezado de la tabla
                $pdf->SetFont('Arial', 'B', 10);

                // Imprimir los encabezados de la tabla
                $pdf->Cell(30, 10, 'Id Inventario', 1, 0, 'C');
                $pdf->Cell(25, 10, 'Id Producto', 1, 0, 'C');
                $pdf->Cell(20, 10, 'Stock', 1, 0, 'C');
                $pdf->Cell(20, 10, 'Hora', 1, 0, 'C');
                $pdf->Cell(20, 10, 'Fecha', 1, 1, 'C');
               
            
                // Establecer la fuente y el tamaño del contenido de la tabla
                $pdf->SetFont('Arial', '', 9);

                // Imprimir los datos de la tabla
                while ($row = $Consulta->fetch_assoc()) {
                    $pdf->Cell(30, 10, $row["id_inventario"], 1, 0, 'L');
                    $pdf->Cell(25, 10, $row["id_producto"], 1, 0, 'C');
                    $pdf->Cell(20, 10, $row["stock"], 1, 0, 'C');
                    $pdf->Cell(20, 10, $row["hora"], 1, 0, 'C');
                    $pdf->Cell(20, 10, $row["fecha"], 1, 1  , 'C');
                  
                   
                }

                // Salto de línea después de la tabla
                $pdf->Ln(10);

                $historial->conectar->close();
                // Mostrar el PDF
                $pdf->Output();
            } else {
                echo "No se encontraron registros.";
            }

        }
        else
        {
             $Consulta=$historial->ConsultaGlobal();
             $vista="Vistas/Inventario/frminventario.php";
            include_once("Vistas/frmplantillaAdmin.php");
        }
    }

}
?>




