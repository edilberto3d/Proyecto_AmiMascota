<?php
include_once 'Modelo/clsNosotros.php';
include_once 'LibreriaFPDF/fpdf.php';

class controladornosotros
{
	private $vista;
	
	public function Nosotros()
	{	
		$vista="Vistas/Acceso/frmNosotros.php";
        include_once("Vistas/frmplantilla.php");
    }
}
?>


