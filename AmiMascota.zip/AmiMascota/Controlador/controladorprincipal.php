<?php

include_once 'Modelo/clsFabricante.php';
include_once 'LibreriaFPDF/fpdf.php';

class controladorprincipal
{
	private $vista;
	
	
	public function inicio()
	{	
		$vista="Vistas/Inicio/frmcontenidopublico.php";
        include_once("Vistas/frmplantilla.php");
    }
}
?>