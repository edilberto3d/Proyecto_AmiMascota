
<?php
session_start();
include_once 'Modelo/clsLogin.php';

	class controladorusuarios
{
	private $vista;
	
	
	public function ingresar()
	{	
		//$vista="Vistas/Acceso/frmLogin.php";
        include_once("Vistas/Acceso/frmCrearUsuarios.php");
    }
	
	
	public function CrearUsuario()
	{
		$login=new clsLogin();
		if(!empty($_POST))
		{
			$usuario=$_POST['txtusuario'];
    		$passw=$_POST['txtpassword'];
			$tipo=$_POST['selectTipo'];
			$login->Crearusuarios($usuario,$passw,$tipo);
			include_once ("Vistas/Acceso/frmLogin.php");
		}
		else if ($_SESSION['TipoUsuario']=='Administrador')
		{
			$vista="Vistas/Acceso/frmCrearUsuarios.php";
			include_once("Vistas/frmplantillaAdmin.php");
		}
		else if ($_SESSION['TipoUsuario']=='Normal')
		{
			$vista="Vistas/Acceso/frmDenegado.php";
			include_once("Vistas/frmplantillaAdmin.php");
		}
	}
}
?>
