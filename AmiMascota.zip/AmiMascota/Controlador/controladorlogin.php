<?php
session_start();
include_once 'Modelo/clsLogin.php';


class controladorlogin
{
	private $vista;
	
	
	public function ingresar()
	{	
		//$vista="Vistas/Acceso/frmLogin.php";
        include_once("Vistas/Acceso/frmLogin.php");
    }

    public function Acceder()
    {
    		//ver si hay post
    	$login=new clsLogin();
    	if(!empty($_POST))
    	{
    		$usuario=$_POST['txtusuario'];
    		$passw=$_POST['txtpassword'];
    		$datos=$login->buscausuario($usuario,$passw);
			$usuario=$datos->fetch_object();
    		if($datos->num_rows>0)
    		{
    			$_SESSION['TipoUsuario']=$usuario->tipo;
				if ($_SESSION['TipoUsuario']== 'Administrador'){
					
					$vista="Vistas/Acceso/frmCrearUsuarios.php";
					include_once("Vistas/frmplantillaAdmin.php");
				}
				else if ($_SESSION['TipoUsuario']== 'Normal'){
					$vista="Vistas/Inicio/frmcontenidopublico.php";
					include_once("Vistas/frmplantilla.php");
				}
    		}
    		else
    		{
    			 include_once("Vistas/Acceso/frmDenegado.php");
    		}
    	}

    }
	public function CrearUsuarios()
	{
		$login=new clsLogin();
		if(!empty($_POST))
		{
			$usuario=$_POST['txtusuario'];
    		$passw=$_POST['txtpassword'];
			$tipo=$_POST['selectTipo'];
			$login->CrearlosUsuarios($usuario,$passw,$tipo);
			include_once ("Vistas/Acceso/frmLogin.php");
		}
		else if ($_SESSION['TipoUsuario']=='Administrador')
		{
			$vista="Vistas/Acceso/frmCrearUsuarios.php";
			include_once("Vistas/frmplantillaAdmin.php");
		}
		else if ($_SESSION['TipoUsuario']=='Normal')
		{
			$vista="Vistas/Acceso/frmDenegado.php";
			include_once("Vistas/frmplantilla.php");
		}
	}

	public function CerrarSesion()
	{
		session_destroy();
		include_once ("Vistas/Acceso/frmLogin.php");
	}
}
?>