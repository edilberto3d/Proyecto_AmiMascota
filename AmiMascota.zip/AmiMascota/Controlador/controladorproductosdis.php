<?php
include_once 'Modelo/clsNosotros.php';
include_once 'LibreriaFPDF/fpdf.php';

class controladorproductosdis
{
	private $vista;
	
	public function Disponible()
	{	
		$vista="Vistas/Inventario/frmproductosdisponibles.php";
        include_once("Vistas/frmplantilla.php");
    }
}
?>