<?php
session_start();
include_once 'Modelo/clsReporteUsuarios.php';
include_once 'LibreriaFPDF/fpdf.php';

class controladorreporteUser
{
	private $vista;
	
	public function insertarproductos()
	{
		$fabricante=new clsReporteUsuarios();
		
		if(!empty($_POST))
		{
			$nombre=$_POST['txtnombre'];
			$ap=$_POST['txtapa'];
			$am=$_POST['txtam'];
			$edad=$_POST['txteda'];
			$sexo=$_POST['txtsexo'];
			$telefono=$_POST['txttelefono'];
			$email=$_POST['txtemail'];
			$usuario=$_POST['txtusuario'];
			$contraseña=$_POST['txtcontraseña'];
			$confirmar_contraseña=$_POST['txtconfirmar'];

			$fabricante->insertarfabricante($nombre,$ap,$am,$edad,$sexo,$telefono,$email,$usuario,$contraseña,$confirmar_contraseña);
			$Consulta=$fabricante->ConsultaFabricante();
			$vista="Vistas/Usuarios/frmReporteUsuarios.php";
        	include_once("Vistas/frmplantilla.php");
		}
		else if($_SESSION['TipoUsuario']=='Administrador')
		{
			$Consulta=$fabricante->ConsultaFabricante();
			$vista="Vistas/Usuarios/frmReporteUsuarios.php";
        	include_once("Vistas/frmplantillaAdmin.php");
			
		}
		else if($_SESSION['TipoUsuario']=='Normal')
		{
			$vista="Vistas/Usuarios/frmReporteUsuarios.php";
			
			include_once("Vistas/frmplantillaAdmin.php");
		}
	}
	
	public function ActualizarXEliminar()
	{	
	
		$fabricante=new clsReporteUsuarios();
		if(!empty($_POST))
		{
			if(isset($_POST['btnActualizar']))
			{
				$id_cliente=$_POST['txtid_cliente'];
				$nombre=$_POST['txtnombre'];
				$ap=$_POST['txtapa'];
				$am=$_POST['txtam'];
				$edad=$_POST['txteda'];
				$sexo=$_POST['txtsexo'];
				$telefono=$_POST['txttelefono'];
				$email=$_POST['txtemail'];
				$usuario=$_POST['txtusuario'];
				$contraseña=$_POST['txtcontraseña'];
				$confirmar_contraseña=$_POST['txtconfirmar'];

				
				$fabricante->Actualizar($id_cliente,$nombre,$ap,$am,$edad,$sexo,$telefono,$email,$usuario,$contraseña,$confirmar_contraseña);
				$Consulta=$fabricante->ConsultaFabricante();
				$vista="Vistas/Usuarios/frmReporteUsuarios.php";
				include_once("Vistas/frmplantillaAdmin.php");
			}
			else if(isset($_POST['btnEliminar']))
			{
				
				$id_cliente=$_POST['txtid_cliente'];
				$fabricante->Eliminar($id_cliente);
				$Consulta=$fabricante->ConsultaFabricante();
				$vista="Vistas/Usuarios/frmReporteUsuarios.php";
				include_once("Vistas/frmplantillaAdmin.php");
			}
			
		}
		else
		{
			$Consulta=$fabricante->ConsultaFabricante();
			$vista="Vistas/Usuarios/frmReporteUsuarios.php";
        	include_once("Vistas/frmplantillaAdmin.php");
		}

    }
}
?>


