<?php

include_once 'Modelo/clsFabricante.php';
include_once 'LibreriaFPDF/fpdf.php';

class controladorfabricante
{
	private $vista;
	
	
	public function iniciaformulario()
	{	
		// $vista="Vistas/Fabricante/frmFabricante.php";
        include_once("Vistas/Clientes/frmclientes.php");
    }
	public function insertarproductos()
	{
		$fabricante=new clsFabricante();
		
		if(!empty($_POST))
		{
			$nombre=$_POST['txtnombre'];
			$ap=$_POST['txtapa'];
			$am=$_POST['txtam'];
			$edad=$_POST['txteda'];
			$sexo=$_POST['txtsexo'];
			$telefono=$_POST['txttelefono'];
			$email=$_POST['txtemail'];
			$usuario=$_POST['txtusuario'];
			$contraseña=$_POST['txtcontraseña'];
			$confirmar_contraseña=$_POST['txtconfirmar'];

			$fabricante->insertarfabricante($nombre,$ap,$am,$edad,$sexo,$telefono,$email,$usuario,$contraseña,$confirmar_contraseña);
			$Consulta=$fabricante->ConsultaFabricante();
			// $vista="Vistas/Fabricante/frmFabricante.php";
        	include_once ("Vistas/Acceso/frmLogin.php");
		}
		
		// else 
		// {
		// 	// $vista="Vistas/Fabricante/frmFabricante.php";
			
		// 	include_once("Vistas/Acceso/frmLogin.php");
		// }
	}
	/*
	public function ActualizarXEliminar()
	{	
	
		$fabricante=new clsFabricante();
		if(!empty($_POST))
		{
			if(isset($_POST['btnActualizar']))
			{
				$id_cliente=$_POST['txtid_cliente'];
				$nombre=$_POST['txtnombre'];
				$ap=$_POST['txtapa'];
				$am=$_POST['txtam'];
				$edad=$_POST['txteda'];
				$sexo=$_POST['txtsexo'];
				$telefono=$_POST['txttelefono'];
				$email=$_POST['txtemail'];
				$usuario=$_POST['txtusuario'];
				$contraseña=$_POST['txtcontraseña'];
				$confirmar_contraseña=$_POST['txtconfirmar'];

				
				$fabricante->Actualizar($id_cliente,$nombre,$ap,$am,$edad,$sexo,$telefono,$email,$usuario,$contraseña,$confirmar_contraseña);
				$Consulta=$fabricante->ConsultaFabricante();
				$vista="Vistas/Fabricante/frmFabricante.php";
				include_once("Vistas/frmplantilla.php");
			}
			else if(isset($_POST['btnEliminar']))
			{
				
				$id_cliente=$_POST['txtid_cliente'];
				$fabricante->Eliminar($id_cliente);
				$Consulta=$fabricante->ConsultaFabricante();
				$vista="Vistas/Fabricante/frmFabricante.php";
				include_once("Vistas/frmplantilla.php");
			}
			
		}
		else
		{
			$Consulta=$fabricante->ConsultaFabricante();
			$vista="Vistas/Fabricante/frmFabricante.php";
        	include_once("Vistas/frmplantilla.php");
		}

    }
	*/
}
?>