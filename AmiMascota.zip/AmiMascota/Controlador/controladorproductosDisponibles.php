<?php
session_start();
include_once 'Modelo/clsProductosDisponibles.php';
include_once 'LibreriaFPDF/fpdf.php';

class controladorproductosDisponibles
{
	private $vista;
	
	public function insertarproductos()
	{
		$productos=new clsProductosDisponibles();
		
		if(!empty($_POST))
		{
			$nombre=$_POST['nombre'];
			$descripcion=$_POST['descripcion'];
			$stock=$_POST['stock'];
			$precio=$_POST['precio'];
			$hora=$_POST['hora'];
			$fecha_registro=$_POST['fecha_registro'];
			$img=$_FILES['txtimagen'];
			$imagengenData=file_get_contents($img['tmp_name']);
			$imagengenData2=$productos->conectar->real_escape_string($imagengenData);
			$id_categoria=$_POST['categoria'];
			$productos->insertarProductos($nombre,$descripcion,$stock,$precio,$hora,$fecha_registro,$imagengenData2,$id_categoria);
			$Consulta=$productos->ConsultaFabricante();
			$productos=new clsProductosDisponibles();
			$Consultaproductos=$productos->ConsultaProducto();
			$vista="Vistas/Inventario/frmproductosdisponibles.php";
        	include_once("Vistas/frmplantilla.php");
		}
		else if($_SESSION['TipoUsuario']=='Administrador')
		{
			$Consulta=$productos->ConsultaFabricante();
			$productos=new clsProductosDisponibles();
			$Consultaproductos=$productos->ConsultaProducto();
			$vista="Vistas/Inventario/frmproductosdisponibles.php";
        	include_once("Vistas/frmplantilla.php");
		}
		else if($_SESSION['TipoUsuario']=='Normal')
		{
			$vista="Vistas/Inventario/frmproductosdisponibles.php";
			
			include_once("Vistas/frmplantilla.php");
		}
	}
	public function ActualizarXEliminar()
	{	
	
		$productos=new clsProductosDisponibles();
		if(!empty($_POST))
		{
			if(isset($_POST['btnActualizar']))
			{
				
				$id_producto=$_POST['txtcodigo_prod'];
				$nombre=$_POST['txtnombre'];
				$descripcion=$_POST['txtdescripcion'];
				$stock=$_POST['txtstock'];
				$precio=$_POST['txtprecio'];
				$hora=$_POST['txthora'];
				$fecha_registro=$_POST['txtfecha'];
				// $img=$_FILES['txtimagen'];
				// $imagengenData=file_get_contents($img['tmp_name']);
				// $imagengenData2=$productos->conectar->real_escape_string($imagengenData);
				$id_categoria=$_POST['txtcategoria'];

				$productos->Actualizar($id_producto,$nombre,$descripcion,$stock,$precio,$hora,$fecha_registro,$id_categoria);
				
				
				$Consulta=$productos->ConsultaFabricante();
				$productos=new clsProductosDisponibles();
				$Consultaproductos=$productos->ConsultaProducto();
				$vista="Vistas/Inventario/frmproductosdisponibles.php";
        		include_once("Vistas/frmplantilla.php");
			}
			else if(isset($_POST['btnEliminar']))
			{
				
				$id_producto=$_POST['txtcodigo_prod'];
				$productos->Eliminar($id_producto);
		
				$Consulta=$productos->ConsultaFabricante();
				$productos=new clsProductosDisponibles();
				$Consultaproductos=$productos->ConsultaProducto();
				$vista="Vistas/Inventario/frmproductosdisponibles.php";
        		include_once("Vistas/frmplantilla.php");
			}
			
		}
		else
		{
			$Consulta=$productos->ConsultaFabricante();
			$Consultaproductos=$productos->ConsultaProducto();
			$vista="Vistas/Inventario/frmproductosdisponibles.php";
        	include_once("Vistas/frmplantilla.php");
		}
    }
}
?>